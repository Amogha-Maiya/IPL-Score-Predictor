Original data source : http://www.cricmetric.com/ipl/ranks/


I have uploaded all the web-scraped datasets from 2008 to 2020 on [Kaggle](https://www.kaggle.com/adityarc19/ipl-player-stats-2008-to-2020)
